# oct 2017 - no longer in use - to_delete
class AddExtraColsToPwbSections < ActiveRecord::Migration[5.0]
  def change
    # add_column :pwb_sections, :flags, :integer, default: 0, index: true, null: false
    # add_column :pwb_sections, :details, :json, default: {}
    # add_column :pwb_sections, :is_page, :boolean, default: false, index: true
    # add_column :pwb_sections, :show_in_top_nav, :boolean, default: false, index: true
    # add_column :pwb_sections, :show_in_footer, :boolean, default: false, index: true
    # add_column :pwb_sections, :key, :string, index: true
  end
end

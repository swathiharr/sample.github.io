## Page Parts

Page parts allow the use of liquid template to render different sections of a page.

Using liquid templates means users only have to edit strings which are then displayed according to the template file.
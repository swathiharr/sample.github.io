var PwbSectionsController = Paloma.controller('Pwb/Sections');

PwbSectionsController.prototype.contact_us = function () { };


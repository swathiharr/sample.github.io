// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.
// below 2 in vendor dir
//= require legacy-1/pwb-admin-vendor
//= require legacy-1/pwb-admin

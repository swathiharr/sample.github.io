// Place all the behaviors and hooks related to the matching controller here.
// All this logic will automatically be available in application.js.
// below 2 in vendor dir
//= require pwb-admin-vendor
//= require pwb-admin

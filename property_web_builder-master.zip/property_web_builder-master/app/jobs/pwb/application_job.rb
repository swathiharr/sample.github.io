module Pwb
  class ApplicationJob < ActiveJob::Base
  end
end

module Pwb
  class ApplicationMailer < ActionMailer::Base
    # default from: 'service@propertywebbuilder.com'
    layout "mailer"
  end
end

module Pwb
  VERSION = '1.4.0'.freeze
end

require 'rails_helper'

module Pwb
  RSpec.describe ApiExt::V1::PropsController, type: :controller do
  end
end

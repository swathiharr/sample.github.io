class ApplicationMailer < ActionMailer::Base
  default from: 'from@propertywebbuilder.com'
  layout 'mailer'
end
